package com.example.hp.wehack;

/**
 * Created by Akanksha on 10/4/2018.
 */

public class json4 {
    String publishedAt;
    String channelTitle;
    String title;

    public String getChannelName() {
        return channelTitle;
    }

    public String getPublishedAt() {
        return publishedAt;
    }

    public String getTitle() {
        return title;
    }
}
