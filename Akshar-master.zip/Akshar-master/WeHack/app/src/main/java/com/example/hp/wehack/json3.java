package com.example.hp.wehack;

/**
 * Created by Akanksha on 10/4/2018.
 */

public class json3 {
    String viewCount;
    String likeCount;
    String dislikeCount;

    public String getLikeCount() {
        return likeCount;
    }

    public String getDislikeCount() {
        return dislikeCount;
    }

    public String getViewCount() {
        return viewCount;
    }
}
