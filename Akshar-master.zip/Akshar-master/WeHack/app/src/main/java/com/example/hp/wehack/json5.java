package com.example.hp.wehack;

/**
 * Created by Akanksha on 10/4/2018.
 */

public class json5 {
    String duration;

    public String getDuration() {
        return duration;
    }
}
